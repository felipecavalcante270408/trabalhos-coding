from decimal import Decimal
from django.test import TestCase
from django.urls import reverse
from .models import Categoria, Produto


class EstoqueTestes(TestCase):
    def setUp(self):
        self.categoria = Categoria.objects.create(nome='Informática')

    def test_pagina_inicial(self):
        self.assertEqual(self.client.get(reverse('inicio')).status_code, 200)

    def test_crud_categoria(self):
        resposta = self.client.post(reverse('categoria_criar'), {'nome': 'Papelaria', 'descricao': 'Itens escolares'})
        self.assertRedirects(resposta, reverse('categoria_lista'))
        categoria = Categoria.objects.get(nome='Papelaria')
        self.assertContains(self.client.get(reverse('categoria_lista')), 'Papelaria')
        self.client.post(reverse('categoria_editar', args=[categoria.pk]), {'nome': 'Escritório', 'descricao': ''})
        categoria.refresh_from_db()
        self.assertEqual(categoria.nome, 'Escritório')
        self.client.post(reverse('categoria_excluir', args=[categoria.pk]))
        self.assertFalse(Categoria.objects.filter(pk=categoria.pk).exists())

    def test_crud_produto(self):
        dados = {'nome': 'Mouse', 'categoria': self.categoria.pk, 'quantidade': 3, 'preco': '49.90'}
        resposta = self.client.post(reverse('produto_criar'), dados)
        self.assertRedirects(resposta, reverse('produto_lista'))
        produto = Produto.objects.get(nome='Mouse')
        self.assertEqual(produto.preco, Decimal('49.90'))
        self.assertContains(self.client.get(reverse('produto_lista')), 'Mouse')
        self.client.post(reverse('produto_editar', args=[produto.pk]), {**dados, 'nome': 'Mouse USB'})
        produto.refresh_from_db()
        self.assertEqual(produto.nome, 'Mouse USB')
        self.client.post(reverse('produto_excluir', args=[produto.pk]))
        self.assertFalse(Produto.objects.filter(pk=produto.pk).exists())

    def test_nao_exclui_categoria_com_produto(self):
        Produto.objects.create(nome='Teclado', categoria=self.categoria, quantidade=2, preco='99.90')
        self.client.post(reverse('categoria_excluir', args=[self.categoria.pk]))
        self.assertTrue(Categoria.objects.filter(pk=self.categoria.pk).exists())

    def test_exclusao_por_get_nao_exclui(self):
        self.client.get(reverse('categoria_excluir', args=[self.categoria.pk]))
        self.assertTrue(Categoria.objects.filter(pk=self.categoria.pk).exists())
