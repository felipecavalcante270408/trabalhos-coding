from django.contrib import messages
from django.db.models import ProtectedError
from django.shortcuts import get_object_or_404, redirect, render

from .forms import CategoriaForm, ProdutoForm
from .models import Categoria, Produto


def inicio(request):
    contexto = {
        'total_categorias': Categoria.objects.count(),
        'total_produtos': Produto.objects.count(),
        'ultimos_produtos': Produto.objects.select_related('categoria').order_by('-criado_em')[:5],
    }
    return render(request, 'produtos/inicio.html', contexto)


def categoria_lista(request):
    return render(request, 'produtos/categoria_lista.html', {
        'categorias': Categoria.objects.all(),
    })


def categoria_criar(request):
    formulario = CategoriaForm(request.POST or None)
    if request.method == 'POST' and formulario.is_valid():
        formulario.save()
        messages.success(request, 'Categoria cadastrada com sucesso.')
        return redirect('categoria_lista')
    return render(request, 'produtos/formulario.html', {
        'formulario': formulario, 'titulo': 'Nova categoria', 'voltar': 'categoria_lista'
    })


def categoria_editar(request, pk):
    categoria = get_object_or_404(Categoria, pk=pk)
    formulario = CategoriaForm(request.POST or None, instance=categoria)
    if request.method == 'POST' and formulario.is_valid():
        formulario.save()
        messages.success(request, 'Categoria atualizada com sucesso.')
        return redirect('categoria_lista')
    return render(request, 'produtos/formulario.html', {
        'formulario': formulario, 'titulo': 'Editar categoria', 'voltar': 'categoria_lista'
    })


def categoria_excluir(request, pk):
    categoria = get_object_or_404(Categoria, pk=pk)
    if request.method == 'POST':
        try:
            categoria.delete()
            messages.success(request, 'Categoria excluída com sucesso.')
        except ProtectedError:
            messages.error(request, 'Não é possível excluir uma categoria com produtos vinculados.')
        return redirect('categoria_lista')
    return render(request, 'produtos/confirmar_exclusao.html', {
        'objeto': categoria, 'tipo': 'categoria', 'voltar': 'categoria_lista'
    })


def produto_lista(request):
    return render(request, 'produtos/produto_lista.html', {
        'produtos': Produto.objects.select_related('categoria').all(),
    })


def produto_criar(request):
    formulario = ProdutoForm(request.POST or None)
    if request.method == 'POST' and formulario.is_valid():
        formulario.save()
        messages.success(request, 'Produto cadastrado com sucesso.')
        return redirect('produto_lista')
    return render(request, 'produtos/formulario.html', {
        'formulario': formulario, 'titulo': 'Novo produto', 'voltar': 'produto_lista',
        'sem_categorias': not Categoria.objects.exists(),
    })


def produto_editar(request, pk):
    produto = get_object_or_404(Produto, pk=pk)
    formulario = ProdutoForm(request.POST or None, instance=produto)
    if request.method == 'POST' and formulario.is_valid():
        formulario.save()
        messages.success(request, 'Produto atualizado com sucesso.')
        return redirect('produto_lista')
    return render(request, 'produtos/formulario.html', {
        'formulario': formulario, 'titulo': 'Editar produto', 'voltar': 'produto_lista'
    })


def produto_excluir(request, pk):
    produto = get_object_or_404(Produto, pk=pk)
    if request.method == 'POST':
        produto.delete()
        messages.success(request, 'Produto excluído com sucesso.')
        return redirect('produto_lista')
    return render(request, 'produtos/confirmar_exclusao.html', {
        'objeto': produto, 'tipo': 'produto', 'voltar': 'produto_lista'
    })
