from django import forms
from .models import Categoria, Produto


class CategoriaForm(forms.ModelForm):
    class Meta:
        model = Categoria
        fields = ['nome', 'descricao']
        widgets = {
            'nome': forms.TextInput(attrs={'placeholder': 'Ex.: Informática'}),
            'descricao': forms.TextInput(attrs={'placeholder': 'Descrição opcional'}),
        }


class ProdutoForm(forms.ModelForm):
    class Meta:
        model = Produto
        fields = ['nome', 'categoria', 'quantidade', 'preco']
        widgets = {
            'nome': forms.TextInput(attrs={'placeholder': 'Ex.: Mouse sem fio'}),
            'quantidade': forms.NumberInput(attrs={'min': '0'}),
            'preco': forms.NumberInput(attrs={'min': '0', 'step': '0.01'}),
        }
