# Trabalho Prático 03 - Coding / ADS

## Estoque Fácil - Sistema de Controle de Estoque

Aplicação web construída com **Django**, com CRUD completo de **categorias** e **produtos** por páginas HTML. Modelos relacionados: `Produto.categoria = ForeignKey(Categoria, on_delete=PROTECT)`.

### Requisitos
- Python 3.10 ou superior
- Internet na instalação inicial das dependências

### Como executar (Windows / PowerShell ou CMD)

1. Extraia o ZIP e abra o terminal na pasta `Trabalho_Pratico_03_Django`, onde fica `manage.py`.
2. Crie e ative um ambiente virtual:

   ```bat
   py -m venv .venv
   .venv\Scripts\activate
   ```

3. Instale as dependências:

   ```bat
   python -m pip install -r requirements.txt
   ```

4. Crie o banco SQLite:

   ```bat
   python manage.py migrate
   ```

5. Execute os testes e inicie o servidor:

   ```bat
   python manage.py test
   python manage.py runserver
   ```

6. Acesse no navegador: **http://127.0.0.1:8000/**

No Linux/macOS, crie o ambiente com `python3 -m venv .venv` e ative com `source .venv/bin/activate`.

### Como demonstrar ao professor
1. Abra **Categorias**, cadastre uma categoria e altere sua descrição.
2. Abra **Produtos**, cadastre um produto escolhendo a categoria; consulte a listagem, edite e exclua.
3. Tente excluir uma categoria ainda associada a um produto: o sistema apresenta uma mensagem explicando por que não é possível.
4. Após excluir os produtos relacionados, exclua a categoria.

### Organização

- `estoque_project/settings.py`: configurações e banco SQLite
- `estoque_project/urls.py`: roteamento principal
- `produtos/models.py`: tabelas e ForeignKey
- `produtos/forms.py`: ModelForms para cadastro e edição
- `produtos/views.py`: operações CRUD
- `produtos/urls.py`: rotas das páginas
- `produtos/templates/produtos/`: páginas HTML do Django
- `produtos/static/produtos/style.css`: identidade visual
- `produtos/migrations/0001_initial.py`: criação inicial das tabelas
- `produtos/tests.py`: testes automatizados

### Dados acadêmicos
Curso: Análise e Desenvolvimento de Sistemas | Disciplina: Coding | Turma: Bloco II (2026.2).

**Atenção:** o enunciado informa prazo em 08/10/2026 às 23h50, data já passada em 17/10/2026. Confirme com o professor se o formulário ainda aceita envios.

O projeto foi preparado para execução local e fins didáticos (DEBUG ligado e chave de desenvolvimento). Não publicar em produção com essas configurações.
